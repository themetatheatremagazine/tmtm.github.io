﻿=== Dark Matter Cursor Set ===

By: Mobius (http://www.rw-designer.com/user/67332) juan.gonzalez.69@hotmail.com

Download: http://www.rw-designer.com/cursor-set/dark-matter

Author's description:

Have you ever wondered, "How a cursor made of Dark Matter would look?" no? Too Bad! Those cursors are made of prism, locking on the inside compressed Dark Matter.

WARNING: Do not break open any of those cursors if you don't want to fill your pc with Dark Matter!

-Mobius 


==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.